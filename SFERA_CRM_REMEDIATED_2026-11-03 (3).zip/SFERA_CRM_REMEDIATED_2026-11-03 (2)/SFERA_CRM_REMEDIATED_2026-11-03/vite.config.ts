/// <reference types="vitest/config" />
import path from 'path'
import { fileURLToPath } from 'url'
import type { IncomingMessage } from 'node:http'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { tanstackRouter } from '@tanstack/router-plugin/vite'
import { playwright } from '@vitest/browser-playwright'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// These API endpoints share their first path segment with client-side pages.
// Keep browser document/deep-link requests in Vite's SPA fallback, while
// continuing to proxy JSON requests to the API server.
const workspaceApiProxy = () => ({
  target: 'http://127.0.0.1:8082',
  changeOrigin: true,
  bypass(req: IncomingMessage) {
    if (req.method === 'GET' && req.headers.accept?.includes('text/html')) {
      return '/index.html'
    }
  },
})

// https://vite.dev/config/
export default defineConfig({
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,
    proxy: {
      '/api': { target: 'http://127.0.0.1:8082', changeOrigin: true },
      '/auth': { target: 'http://127.0.0.1:8082', changeOrigin: true },
      '/dashboard': workspaceApiProxy(),
      '/group': workspaceApiProxy(),
      '/student': workspaceApiProxy(),
      '/attendance': workspaceApiProxy(),
      '/teacher': workspaceApiProxy(),
      '/user': workspaceApiProxy(),
      '/admin': workspaceApiProxy(),
      '/category': workspaceApiProxy(),
      '/room': workspaceApiProxy(),
      '/mark': workspaceApiProxy(),
      '/event': workspaceApiProxy(),
      '/notification': workspaceApiProxy(),
      '/manager': workspaceApiProxy(),
      '/tasks': workspaceApiProxy(),
      '/reports': workspaceApiProxy(),
    },
  },
  plugins: [
    tanstackRouter({
      target: 'react',
      autoCodeSplitting: true,
    }),
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    chunkSizeWarningLimit: 800,
  },
  test: {
    silent: 'passed-only',
    unstubEnvs: true,
    browser: {
      enabled: true,
      provider: playwright(),
      instances: [{ browser: 'chromium' }],
    },
    coverage: {
      // include: ['src/**/*.{js,jsx,ts,tsx}'], // Uncomment to expand the report to all src/**/* so untested modules appear as 0% coverage.
      exclude: [
        'src/components/ui/**',
        'src/assets/**',
        'src/tanstack-table.d.ts',
        'src/routeTree.gen.ts',
        'src/test-utils/**',
        'src/routes/**',
      ],
    },
  },
})
