# SFERA CRM — API endpoint matrix (verified subset)

**Current status:** Partial; not a complete generated contract. Canonical rewrites and gaps are in [`RELEASE_API_CONTRACT.md`](RELEASE_API_CONTRACT.md). Backend controllers are in `backend/src/main/java/sfera/crmsfera/controller/`.

| Frontend/API path | Backend path | Method | Authorization/contract status |
|---|---|---:|---|
| `/api/v1/auth/login` | `/auth/login` | POST | Route exists; response user role is manually decoded from JWT and requires complete auth contract tests. |
| `/api/v1/dashboard/summary` | `/dashboard` | GET | Client alias exists; all role aggregation not E2E verified. |
| `/api/v1/dashboard/teacher` | `/dashboard/teacher` | GET | Alias exists; teacher API mode shows backend-returned metrics only. |
| `/teacher/groups` | `/group/all` | GET | Principal-scoped teacher groups; attendance UI uses real numeric IDs. |
| `/api/v1/attendance/bulk` | `/attendance/bulk` | POST | Envelope adapter is tested; delegates to secured canonical attendance service. UI statuses `late`/`excused` map to same backend `SABABLI` enum. |
| `/api/v1/attendance/{id}` | `/attendance/{id}` | GET | Per-record ownership checks covered by backend regressions. |
| `/api/v1/tasks` | `/tasks` | GET/POST | Partial update and teacher group/user scope have targeted tests; full tenant/role matrix remains open. |
| `/api/v1/tasks/{id}` | `/tasks/{id}` | PUT/DELETE | Controller accepts frontend ID path and partial update retains omitted associations; not all DTO/security cases are contract-tested. |
| `/api/v1/finance/summary` | same | GET | Payment aggregates are supported; invoice-ledger values unavailable. |
| `/api/v1/finance/payments` | same | GET/POST | Payment workflow exists but no complete invoice/refund/receipt system. |
| `/api/v1/finance/payments/{id}/approve` | same | POST | Admin/Super Admin controller policy; full role E2E not run. |
| `/api/v1/finance/payments/{id}/reject` | same | POST | Admin/Super Admin controller policy; full role E2E not run. |
| `/api/v1/leads/*`, `/api/v1/courses/*` | Not fully verified here | mixed | Do not treat local/demo data as production functionality. |

This matrix omits many routes. DTOs, errors/status codes, pagination/filter semantics, ownership, role scopes, academy isolation and every frontend API call remain open. Review `RELEASE_API_CONTRACT.md` and `SUPPLEMENTAL_AUDIT_REVIEW.md` before relying on an endpoint in production.
