# MANUS STUDIO — SFERA CRM TO‘LIQ TUZATISH UCHUN MASTER PROMPT

Sen senior full-stack engineer, software architect, application security engineer va QA automation engineer sifatida ishlaysan.

Men senga SFERA CRM loyihasining to‘liq ZIP arxivini berdim. ZIP ichida React frontend va canonical Spring Boot backend bor. Maqsad — frontend va backendni bir-biri bilan to‘liq, xavfsiz va real PostgreSQL database orqali ishlaydigan holatga keltirish. Faqat audit yoki tavsiya yozib to‘xtama: kodni amalda tuzat, test qil va yangi yakuniy ZIP tayyorla.

## Birinchi navbatda o‘qi

1. `docs/MANUS_REMEDIATION_MASTER_PLAN_UZ.md` — barcha ma’lum xatolar, blockerlar, ishlar va acceptance criteria.
2. `RELEASE_AUDIT.md`
3. `SUPPLEMENTAL_AUDIT_REVIEW.md`
4. `RELEASE_TEST_REPORT.md`
5. `RELEASE_API_CONTRACT.md`
6. `API_ENDPOINT_MATRIX.md`
7. `TASKS/01_MASTER_AUDIT_BARCHA_KAMCHILIKLAR.md`
8. `TASKS/03_TEST_ACCEPTANCE_MATRIX.md`

**Canonical backend faqat ZIP root ichidagi `backend/` Spring Boot loyihasi.** Boshqa eski/standalone backendni ko‘r-ko‘rona merge yoki deploy qilma.

## Asosiy vazifa

1. Source’ni to‘liq inventarizatsiya qil. Har eski findingni joriy kodda qayta tekshir va FIXED/OPEN/PARTIAL/NOT REPRODUCED/NOT TESTED deb dalil bilan belgilagin.
2. Frontenddagi barcha API chaqiruvlarini backend controller/DTO/service bilan mapping qil. Yetishmayotgan endpoint yoki mos kelmaydigan DTO/enum/error/paginationni tuzat.
3. Avval P0 security/auth/tenant muammolarini yop: yagona auth, HttpOnly Secure session yoki asosli BFF, refresh/revocation/logout, password reset, rate limit, Parent va Student rollarini ajratish, server-side RBAC/ownership/academy isolation, CORS/CSRF/secrets/file security.
4. P1 biznes modullarini real database bilan tugat: Finance invoice/debt/payment allocation/partial payment/refund/receipt/reconciliation; Student/Parent lifecycle; Leads/conversion/enrollment; Groups/Courses/Schedule; Teacher attendance/tasks/assignments/submissions/grades; notifications/reports.
5. Barcha production frontend ekranlarini haqiqiy backend API bilan bog‘la. API mode’da mock/localStorage/demo fallback bo‘lmasin. Saqlanmagan ma’lumotni saqlandi deb ko‘rsatma.
6. DB integrity, Flyway, concurrency, constraints, money precision, timezone, phone normalization va query performance tekshir.
7. SUPER_ADMIN, ADMIN, MANAGER, TEACHER, FINANCE, STUDENT, PARENT rollari uchun E2E test yoz.
8. Responsive, accessibility, localization, Lighthouse/performance va lint warninglarni ko‘rib chiq.
9. Hujjatlar va test hisobotlarini yangila.

## Qat’iy talablar

- Loyihani noldan yozma; mavjud arxitektura va biznes mantiqni saqla.
- Testlarni o‘chirma, skip qilma, assertionni kuchsizlantirma.
- `RELEASE_TEST_REPORT.md` 158/158 frontend va 29/29 backend natijalarini qayd etadi; ularni yangi muhitda qayta tekshir. Eski 79/156 baseline’ni joriy natija deb ko‘rsatma.
- PostgreSQL/tashqi servis yo‘q bo‘lsa BLOCKED, hech qachon PASS emas.
- Secret/token/password/production data’ni ZIPga kiritma.
- Har finding uchun root cause, o‘zgargan fayllar, migration, test command va haqiqiy natija.
- Fake data, random KPI, fake invoice ID, fake payment success yoki fake save/invite/export bo‘lmasin.
- `FinanceService`dagi `"INV-" + payment.getId()` kabi payment ID’dan yasalgan qiymatni haqiqiy invoice ID deb ko‘rsatma; canonical invoice relation yaratilishi kerak.
- PARENT va STUDENT hech qachon bir xil role bo‘lmasin.
- Frontend route guard backend authorization o‘rnini bosmaydi.
- FIXED faqat code + passing regression/integration test + evidence bilan.
- P0/P1 qolsa release BLOCKED.

## Yakuniy natija

Ishni bosqichma-bosqich amalda bajar. Oxirida bitta yangi ZIP topshir: to‘liq frontend, canonical Spring Boot backend, Flyway migrations, xavfsiz `.env.example`, yangilangan README, `MANUS_REMEDIATION_TRACKER.md`, to‘liq API contract, security va database migration hisobotlari, frontend/backend/E2E test loglari va qolgan blockerlar.

Yakuniy hisobotda aniq ko‘rsat:
1. Qaysi findinglar FIXED, OPEN yoki BLOCKED.
2. Qaysi fayllar o‘zgargan.
3. Har testning PASS/FAIL/BLOCKED natijasi va log manzili.
4. Frontend–backend endpoint mosligi.
5. Har role bo‘yicha E2E natija.
6. Finance ledger va Student/Parent workflow natijasi.
7. Production release qarori.

**Ishni faqat audit hujjati yozish bilan tugatma. Kodni amalda tuzatish va dalil bilan tekshirish asosiy vazifa.**
