# API contract status

Date: 2026-10-30

## Verified contract areas

The frontend uses the bundled backend as the canonical API source. Existing endpoint families include authentication, users/parents/teachers/students, groups, attendance, marks, tasks, notifications, and finance payments/summary.

The finance endpoints currently used by the frontend are:

```text
GET  /api/v1/finance/summary
GET  /api/v1/finance/payments
POST /api/v1/finance/payments
POST /api/v1/finance/payments/{id}/approve
POST /api/v1/finance/payments/{id}/reject
```

Payment creation requires `studentId`, positive `amount`, `paymentMethod`, and an `idempotencyKey`. Payment approval and rejection are role-restricted, and the creator cannot approve or reject their own payment.

## Contract/security changes in this phase

JWT configuration now requires issuer, audience, and access token type. Parent collection endpoints are admin-only; child-specific endpoints remain authenticated. Task reads require authentication.

## Not yet final

The contract is not final for invoice/debt/receipt/refund/reversal, refresh/revoke/password reset, tenant scope, file authorization, attendance correction, grade publication, and lead conversion. These areas require implementation plus integration tests before the document can be treated as a production contract.
