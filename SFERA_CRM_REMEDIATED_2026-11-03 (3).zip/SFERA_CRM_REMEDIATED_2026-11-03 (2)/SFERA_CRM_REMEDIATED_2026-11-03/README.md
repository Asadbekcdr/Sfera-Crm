# SFERA CRM — Frontend + canonical Spring Boot backend

This repository contains the existing SFERA CRM React/TypeScript/Vite frontend and its canonical backend under `backend/` (Java 17, Spring Boot, PostgreSQL, Flyway). The separate backend archive supplied for comparison is not the deployment source. This project is not a NestJS/Drizzle application.

## Prerequisites

- Node.js 22 or newer and pnpm 11
- JDK 17 or newer
- PostgreSQL available locally or remotely

## Configure and start the backend

Create an empty PostgreSQL database and copy `.env.example` to `.env`. Replace the database credentials and `JWT_SECRET`; the JWT secret must be a strong, random value of at least 32 bytes. Do not commit `.env` or use the example placeholder in a deployed environment.

The backend reads standard environment variables. In a shell, load the configured values and run:

```bash
set -a
. ./.env
set +a
cd backend
./mvnw spring-boot:run
```

The backend listens on port `8082` by default. Flyway is enabled by default and Hibernate uses `ddl-auto=validate`; database changes are managed by `backend/src/main/resources/db/migration/`. Swagger UI is exposed at `/swagger-ui.html` when the service is running.

## Configure and start the frontend

From the repository root:

```bash
pnpm install --frozen-lockfile
cp .env.example .env  # only if you have not configured it already
pnpm dev
```

Vite serves the app at `http://localhost:5173` and proxies the configured API route prefixes to `http://127.0.0.1:8082`. `VITE_API_ENABLED=true` is the default. The shared API-mode guard cannot be disabled in production builds, even if `VITE_API_ENABLED=false` is accidentally configured. Some modules still have local/demo behavior that is not yet fully integrated; do not treat this application as production ready.

## Quality checks

Frontend:

```bash
pnpm exec tsc -b --pretty false
pnpm lint
pnpm test
pnpm build
```

Backend (with a reachable PostgreSQL database and test-only configuration):

```bash
cd backend
JWT_SECRET='use-a-random-test-only-secret-of-at-least-32-bytes' \
SPRING_DATASOURCE_URL='jdbc:postgresql://127.0.0.1:5432/academy' \
SPRING_DATASOURCE_USERNAME='postgres' \
SPRING_DATASOURCE_PASSWORD='your-local-password' \
./mvnw test
```

For the latest run-specific evidence and the unresolved blocker list, see `CURRENT_REMEDIATION_STATUS_UZ.md` and `release-evidence/current/README.md`. Historical audit and test records are in `RELEASE_AUDIT.md`, `RELEASE_TEST_REPORT.md`, `RELEASE_CHANGELOG.md`, and `RELEASE_API_CONTRACT.md`.

## Release status

**BLOCKED — not production ready.** Latest evidence from 2026-11-03: frontend browser suite 159/159; TypeScript, lint (0 errors/29 warnings), production build and backend 44/44 pass. Backend tests ran against a fresh test-only PostgreSQL database with Flyway V1–V3. This run did not test a legacy-schema upgrade or full role-based E2E. Remaining blockers include browser-readable JWT/session lifecycle, revocation/rate limiting, Clerk/JWT duplication, academy/tenant isolation, incomplete role authorization/workflows, student lifecycle, teacher assignment/grade persistence, and a canonical invoice/debt/refund/receipt ledger. Some modules still use local/demo behavior. See `CURRENT_REMEDIATION_STATUS_UZ.md` for exact evidence and the complete remaining blocker list.

## Main directories

- `src/` — React frontend, TanStack Router routes, role views and shared UI.
- `backend/` — canonical Spring Boot API, JPA entities, repositories, services, Flyway migrations and tests.
- `backend/src/main/resources/db/migration/` — versioned database schema changes.
