package sfera.crmsfera.security;

import jakarta.servlet.ServletException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JwtAuthFilterTest {
    @Mock JwtService jwtService;
    @Mock CustomUserDetailsService userDetailsService;

    private JwtAuthFilter filter;

    @BeforeEach
    void setUp() {
        SecurityContextHolder.clearContext();
        filter = new JwtAuthFilter(jwtService, userDetailsService);
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void disabledPrincipalIsNotAuthenticatedEvenWhenTokenIsOtherwiseValid() throws ServletException, IOException {
        String token = "signed-but-account-disabled";
        String phone = "998901234567";
        UserDetails disabled = mock(UserDetails.class);
        when(disabled.isEnabled()).thenReturn(false);
        when(jwtService.extractUsername(token)).thenReturn(phone);
        when(userDetailsService.loadUserByUsername(phone)).thenReturn(disabled);

        MockFilterChain chain = runFilter(token);

        assertNull(SecurityContextHolder.getContext().getAuthentication());
        assertNotNull(chain.getRequest(), "the request must continue anonymously to Spring Security");
        verify(jwtService, never()).isTokenValid(anyString(), any());
    }

    @Test
    void enabledPrincipalIsAuthenticatedWhenTokenIsValid() throws ServletException, IOException {
        String token = "valid-token";
        String phone = "998901234567";
        UserDetails enabled = mock(UserDetails.class);
        when(enabled.isEnabled()).thenReturn(true);
        doReturn(List.of(new SimpleGrantedAuthority("ROLE_STUDENT")))
                .when(enabled).getAuthorities();
        when(jwtService.extractUsername(token)).thenReturn(phone);
        when(userDetailsService.loadUserByUsername(phone)).thenReturn(enabled);
        when(jwtService.isTokenValid(token, enabled)).thenReturn(true);

        MockFilterChain chain = runFilter(token);

        assertNotNull(SecurityContextHolder.getContext().getAuthentication());
        assertSame(enabled, SecurityContextHolder.getContext().getAuthentication().getPrincipal());
        assertNotNull(chain.getRequest());
    }

    private MockFilterChain runFilter(String token) throws ServletException, IOException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer " + token);
        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain chain = new MockFilterChain();
        filter.doFilter(request, response, chain);
        return chain;
    }
}
