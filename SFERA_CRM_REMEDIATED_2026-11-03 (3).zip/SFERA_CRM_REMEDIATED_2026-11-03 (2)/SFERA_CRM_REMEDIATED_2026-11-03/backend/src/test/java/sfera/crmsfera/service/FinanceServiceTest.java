package sfera.crmsfera.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqPayment;
import sfera.crmsfera.entity.Payment;
import sfera.crmsfera.entity.Student;
import sfera.crmsfera.entity.enums.PaymentStatus;
import sfera.crmsfera.repository.PaymentRepository;
import sfera.crmsfera.repository.StudentRepository;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FinanceServiceTest {
    @Mock PaymentRepository paymentRepository;
    @Mock StudentRepository studentRepository;

    private FinanceService service() {
        return new FinanceService(paymentRepository, studentRepository);
    }

    @Test
    void alreadyApprovedPaymentCannotBeApprovedAgain() {
        Payment payment = Payment.builder()
                .status(PaymentStatus.APPROVED)
                .submittedBy("998901111111")
                .approvedBy("998902222222")
                .approvedAt(Instant.now())
                .build();
        when(paymentRepository.findById(7L)).thenReturn(Optional.of(payment));

        assertThrows(IllegalStateException.class,
                () -> service().approve("ROLE_ADMIN", "998903333333", 7L));
    }

    @Test
    void rejectedPaymentCannotBeApproved() {
        Payment payment = Payment.builder()
                .status(PaymentStatus.REJECTED)
                .submittedBy("998901111111")
                .build();
        when(paymentRepository.findById(8L)).thenReturn(Optional.of(payment));

        assertThrows(IllegalStateException.class,
                () -> service().approve("ROLE_SUPER_ADMIN", "998903333333", 8L));
    }

    @Test
    void sameNormalizedIdempotencyRequestReturnsOriginalPayment() {
        Student student = Student.builder().fullName("Ali Valiyev").build();
        student.setId(21L);
        Payment existing = Payment.builder()
                .student(student)
                .amount(new BigDecimal("125.00"))
                .paymentMethod("CASH")
                .idempotencyKey("school-fee-2026")
                .referenceNumber("receipt-7")
                .submittedBy("998901234567")
                .status(PaymentStatus.PENDING_APPROVAL)
                .build();
        existing.setId(31L);
        when(paymentRepository.findByIdempotencyKey("school-fee-2026")).thenReturn(Optional.of(existing));

        ApiResponse<Map<String, Object>> result = service().create(
                "ROLE_FINANCE", "998901234567", request(" school-fee-2026 ", new BigDecimal("125.00")));

        assertTrue(result.isSuccess());
        assertEquals("31", result.getData().get("id"));
        verify(studentRepository, never()).findById(anyLong());
        verify(paymentRepository, never()).save(any());
    }

    @Test
    void idempotencyKeyCannotBeReusedForDifferentAmount() {
        Student student = Student.builder().fullName("Ali Valiyev").build();
        student.setId(21L);
        Payment existing = Payment.builder()
                .student(student)
                .amount(new BigDecimal("125.00"))
                .paymentMethod("CASH")
                .idempotencyKey("school-fee-2026")
                .referenceNumber("receipt-7")
                .submittedBy("998901234567")
                .status(PaymentStatus.PENDING_APPROVAL)
                .build();
        when(paymentRepository.findByIdempotencyKey("school-fee-2026")).thenReturn(Optional.of(existing));

        ResponseStatusException error = assertThrows(ResponseStatusException.class,
                () -> service().create("ROLE_FINANCE", "998901234567",
                        request("school-fee-2026", new BigDecimal("126.00"))));

        assertEquals(HttpStatus.CONFLICT, error.getStatusCode());
        verify(studentRepository, never()).findById(anyLong());
        verify(paymentRepository, never()).save(any());
    }

    @Test
    void summaryUsesActualPaymentAggregatesAndDoesNotInventInvoiceMetrics() {
        when(paymentRepository.sumAmount(eq(PaymentStatus.APPROVED), any(Instant.class), any(Instant.class)))
                .thenReturn(new BigDecimal("150.00"));
        when(paymentRepository.sumAmount(eq(PaymentStatus.REFUNDED), any(Instant.class), any(Instant.class)))
                .thenReturn(new BigDecimal("20.00"));
        when(paymentRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThan(any(), any())).thenReturn(8L);
        when(paymentRepository.countByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThan(
                eq(PaymentStatus.PENDING_APPROVAL), any(), any())).thenReturn(2L);
        when(paymentRepository.countByStatusAndPaidAtGreaterThanEqualAndPaidAtLessThan(
                eq(PaymentStatus.APPROVED), any(), any())).thenReturn(5L);
        when(paymentRepository.countByStatusAndPaidAtGreaterThanEqualAndPaidAtLessThan(
                eq(PaymentStatus.REFUNDED), any(), any())).thenReturn(1L);

        ApiResponse<Map<String, Object>> result = service().summary("ROLE_FINANCE");
        Map<String, Object> data = result.getData();
        Map<?, ?> counts = (Map<?, ?>) data.get("counts");

        assertEquals(150.0, data.get("collectedRevenue"));
        assertEquals(20.0, data.get("totalRefunded"));
        assertEquals(130.0, data.get("netRevenue"));
        assertNull(data.get("invoicesIssued"));
        assertNull(data.get("outstandingBalance"));
        assertNull(data.get("overdueBalance"));
        assertNull(data.get("collectionRate"));
        assertNull(counts.get("invoices"));
        assertEquals(8L, counts.get("payments"));
        assertEquals(2L, counts.get("pendingPayments"));
        assertEquals(5L, counts.get("approvedPayments"));
        assertEquals(1L, counts.get("refunds"));
    }

    private ReqPayment request(String idempotencyKey, BigDecimal amount) {
        ReqPayment request = new ReqPayment();
        request.setStudentId(21L);
        request.setAmount(amount);
        request.setPaymentMethod(" CASH ");
        request.setIdempotencyKey(idempotencyKey);
        request.setReferenceNumber(" receipt-7 ");
        return request;
    }
}
