package sfera.crmsfera.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.transaction.annotation.Transactional;
import sfera.crmsfera.entity.Group;
import sfera.crmsfera.entity.Student;
import sfera.crmsfera.entity.User;
import sfera.crmsfera.entity.enums.Role;
import sfera.crmsfera.entity.enums.WeekDays;

import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@Transactional
class StudentRepositoryTeacherScopeIntegrationTest {
    @Autowired StudentRepository studentRepository;
    @Autowired UserRepository userRepository;
    @Autowired GroupRepository groupRepository;

    @Test
    void searchForTeacherReturnsOnlyStudentsInThatTeachersGroups() {
        User teacherOne = saveTeacher("998900001001");
        User teacherTwo = saveTeacher("998900001002");
        Group groupOne = saveGroup("Group One", teacherOne);
        Group groupTwo = saveGroup("Group Two", teacherTwo);
        Student ownStudent = saveStudent("Own Student", "998900002001", groupOne);
        saveStudent("Other Student", "998900002002", groupTwo);

        var results = studentRepository.searchStudentsForTeacher(null, teacherOne.getId(), PageRequest.of(0, 20));

        assertEquals(1, results.getTotalElements());
        assertEquals(ownStudent.getId(), results.getContent().get(0).getId());
        assertEquals("Own Student", results.getContent().get(0).getFullName());
    }

    private User saveTeacher(String phone) {
        return userRepository.saveAndFlush(User.builder()
                .phone(phone)
                .password("test-only-hash")
                .fullName("Test Teacher")
                .role(Role.ROLE_TEACHER)
                .build());
    }

    private Group saveGroup(String name, User teacher) {
        Group group = Group.builder()
                .name(name)
                .startTime(LocalTime.of(9, 0))
                .endTime(LocalTime.of(10, 0))
                .weekDays(List.of(WeekDays.MONDAY))
                .teacher(teacher)
                .build();
        group.setActive(true);
        return groupRepository.saveAndFlush(group);
    }

    private Student saveStudent(String name, String phone, Group group) {
        Student student = Student.builder()
                .fullName(name)
                .phone(phone)
                .password("test-only-hash")
                .group(group)
                .build();
        student.setActive(true);
        return studentRepository.saveAndFlush(student);
    }
}
