package sfera.crmsfera.controller;

import org.junit.jupiter.api.Test;
import sfera.crmsfera.dto.AttendanceDto;
import sfera.crmsfera.dto.request.ReqAttendanceBulk;
import sfera.crmsfera.entity.enums.AttendaceEnum;
import sfera.crmsfera.security.CustomUserDetails;
import sfera.crmsfera.service.AttendanceService;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class AttendanceControllerBulkTest {
    @Test
    void mapsBulkEnvelopeIntoCanonicalAttendanceRecords() {
        AttendanceService service = mock(AttendanceService.class);
        AttendanceController controller = new AttendanceController(service);
        CustomUserDetails principal = mock(CustomUserDetails.class);
        LocalDate date = LocalDate.of(2026, 10, 30);
        AttendanceDto record = AttendanceDto.builder().studentId(22L).status(AttendaceEnum.KELDI).build();
        ReqAttendanceBulk request = ReqAttendanceBulk.builder().groupId(7L).sessionDate(date)
                .records(List.of(record)).build();

        controller.saveAttendanceBulk(principal, request);

        assertEquals(date, record.getDate());
        verify(service).saveAttendance(eq(principal), eq(7L), eq(List.of(record)));
    }

    @Test
    void rejectsIncompleteBulkEnvelopeBeforeCallingService() {
        AttendanceService service = mock(AttendanceService.class);
        AttendanceController controller = new AttendanceController(service);
        ReqAttendanceBulk request = ReqAttendanceBulk.builder().groupId(7L).records(List.of()).build();

        org.junit.jupiter.api.Assertions.assertThrows(sfera.crmsfera.exception.BadRequestException.class,
                () -> controller.saveAttendanceBulk(mock(CustomUserDetails.class), request));
        verifyNoInteractions(service);
    }
}
