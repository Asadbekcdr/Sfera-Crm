package sfera.crmsfera.service;

import org.junit.jupiter.api.Test;
import sfera.crmsfera.mapper.AttendanceMapper;
import sfera.crmsfera.repository.AttendanceRepository;
import sfera.crmsfera.repository.GroupRepository;
import sfera.crmsfera.repository.StudentRepository;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

class AttendanceSseIsolationTest {
    @Test
    void attendanceSnapshotIsDeliveredOnlyToSubscribersOfThatGroup() {
        TestAttendanceService service = new TestAttendanceService();
        service.subscribe(10L);
        service.subscribe(20L);

        service.sendToGroup(20L, List.of("group-20-attendance"));

        assertEquals(0, service.emitters.get(0).sentEvents);
        assertEquals(1, service.emitters.get(1).sentEvents);
    }

    private static final class TestAttendanceService extends AttendanceService {
        private final List<RecordingEmitter> emitters = new ArrayList<>();

        private TestAttendanceService() {
            super(mock(AttendanceRepository.class), mock(GroupRepository.class),
                    mock(StudentRepository.class), mock(AttendanceMapper.class));
        }

        @Override
        protected SseEmitter createEmitter() {
            RecordingEmitter emitter = new RecordingEmitter();
            emitters.add(emitter);
            return emitter;
        }
    }

    private static final class RecordingEmitter extends SseEmitter {
        private int sentEvents;

        @Override
        public void send(SseEventBuilder builder) throws IOException {
            sentEvents++;
        }
    }
}
