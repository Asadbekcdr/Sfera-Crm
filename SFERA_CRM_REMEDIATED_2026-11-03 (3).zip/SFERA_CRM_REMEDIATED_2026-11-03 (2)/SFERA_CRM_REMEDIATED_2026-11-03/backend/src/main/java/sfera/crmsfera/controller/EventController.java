package sfera.crmsfera.controller;

import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqEvent;
import sfera.crmsfera.dto.request.ReqEventDTO;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import sfera.crmsfera.service.EventService;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/event")
@RequiredArgsConstructor
public class EventController {
    private final EventService eventService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ROLE_MANAGER','ROLE_ADMIN','ROLE_SUPER_ADMIN','ROLE_TEACHER')")
    @Operation(summary = "Event saqlash")
    public ResponseEntity<ApiResponse<String>> saveEvent(@RequestBody ReqEvent reqEvent){
        return ResponseEntity.ok(eventService.addEvent(reqEvent));
    }


    @PutMapping("/update")
    @PreAuthorize("hasAnyRole('ROLE_MANAGER','ROLE_ADMIN','ROLE_SUPER_ADMIN','ROLE_TEACHER')")
    @Operation(summary = "Eventni update qilish")
    public ResponseEntity<ApiResponse<String>> updateEvent(@RequestBody ReqEventDTO reqEventDTO){
        return ResponseEntity.ok(eventService.updateEvent(reqEventDTO));
    }


    @DeleteMapping("/{eventId}")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    @Operation(summary = "Eventni uchirish")
    public ResponseEntity<ApiResponse<String>> deleteEvent(@PathVariable Long eventId){
        return ResponseEntity.ok(eventService.deleteEvent(eventId));
    }


    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @PreAuthorize("isAuthenticated()")
    public SseEmitter stream() {
        SseEmitter emitter = eventService.addEmitter();

        try {
            emitter.send(SseEmitter.event()
                    .name("events")
                    .data(eventService.reqEvent().getData()));
        } catch (Exception e) {
            emitter.completeWithError(e);
        }

        return emitter;
    }


    @GetMapping("/list")
    public ResponseEntity<ApiResponse<List<ReqEventDTO>>> getEventList(){
        return ResponseEntity.ok(eventService.reqEvent());
    }

    @GetMapping("/byDate")
    public ResponseEntity<ApiResponse<List<ReqEventDTO>>> getEventListByDate(@RequestParam LocalDate date){
        return ResponseEntity.ok(eventService.getByDate(date));
    }

}
