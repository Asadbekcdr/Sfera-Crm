package sfera.crmsfera.controller;

import sfera.crmsfera.configuration.TrackAction;
import sfera.crmsfera.dto.*;
import sfera.crmsfera.dto.request.AuthRegister;
import sfera.crmsfera.dto.response.ResPageable;
import sfera.crmsfera.dto.response.ResStudent;
import sfera.crmsfera.dto.response.UserResponse;
import sfera.crmsfera.entity.enums.ActionType;
import sfera.crmsfera.entity.enums.AttendancePeriodFilter;
import sfera.crmsfera.entity.enums.PeriodFilter;
import sfera.crmsfera.entity.enums.Role;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import sfera.crmsfera.security.CustomUserDetails;
import sfera.crmsfera.service.AuthService;
import sfera.crmsfera.service.UserService;

import java.util.List;

@RestController
@RequestMapping("/parent")
@RequiredArgsConstructor
public class ParentController {

    private final AuthService authService;
    private final UserService userService;

    @TrackAction(
            type = ActionType.PARENT_CREATED,
            description = "Ota-ona yaratildi"
    )
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN', 'ROLE_PARENT')")
    @PostMapping
    public ResponseEntity<ApiResponse<String>> parentLogin(
            @Valid @RequestBody AuthRegister register
    ){
        return ResponseEntity.ok(authService.saveUser(register, Role.ROLE_PARENT));
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN', 'ROLE_PARENT')")
    @PutMapping
    public ResponseEntity<ApiResponse<String>> updateParent(@AuthenticationPrincipal CustomUserDetails customUserDetails,
                                                            @Valid @RequestBody UserDTO userDTO){
        return ResponseEntity.ok(userService.update(customUserDetails, userDTO));
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<String>> deleteParent(@PathVariable Long id){
        return ResponseEntity.ok(userService.deleteById(id));
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @GetMapping
    public ResponseEntity<ApiResponse<ResPageable>> getParent(@RequestParam(required = false) String name,
                                                              @RequestParam(required = false) String phone,
                                                              @RequestParam(defaultValue = "0") int page,
                                                              @RequestParam(defaultValue = "10") int size){
        return ResponseEntity.ok(userService.getAllUsersSearch(name,phone,Role.ROLE_PARENT,page,size));
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<UserResponse>> getParentById(@PathVariable Long id){
        return ResponseEntity.ok(userService.getOneUser(id));
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @GetMapping("/list")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllParents(){
        return ResponseEntity.ok(userService.getAllList(Role.ROLE_PARENT));
    }


    @GetMapping("/my-child")
    public ResponseEntity<ApiResponse<List<ResStudent>>> getAllChilds(
            @AuthenticationPrincipal CustomUserDetails customUserDetails){
        return ResponseEntity.ok(userService.getAllStudentsByParent(customUserDetails));
    }


    @GetMapping("/{studentId}/attendance")
    public ApiResponse<List<WeekAttendanceDTO>> attendance(
            @AuthenticationPrincipal CustomUserDetails cud,
            @PathVariable Long studentId,
            @RequestParam(defaultValue = "WEEKLY") AttendancePeriodFilter filter) {
        return userService.getAttendance(cud, studentId, filter);
    }



    @GetMapping("/{studentId}/marks")
    public ApiResponse<List<WeekMarkDTO>> marks(
            @AuthenticationPrincipal CustomUserDetails cud,
            @PathVariable Long studentId,
            @RequestParam(defaultValue = "WEEKLY") PeriodFilter filter
    ) {
        return userService.getMarks(cud, studentId, filter);
    }


    @GetMapping("/{studentId}/stats")
    public ApiResponse<StudentStatsDTO> getStats(
            @AuthenticationPrincipal CustomUserDetails parent,
            @PathVariable Long studentId
    ) {
        return userService.getStats(parent, studentId);
    }




}
