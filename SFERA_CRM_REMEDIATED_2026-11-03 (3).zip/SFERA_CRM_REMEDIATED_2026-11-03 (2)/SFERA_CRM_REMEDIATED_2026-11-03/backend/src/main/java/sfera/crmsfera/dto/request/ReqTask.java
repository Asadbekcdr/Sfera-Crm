package sfera.crmsfera.dto.request;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ReqTask {

    private Long taskId;

    private Long userId;

    private Long groupId;

    private String title;

    private String description;

    private LocalDate deadline;
}
