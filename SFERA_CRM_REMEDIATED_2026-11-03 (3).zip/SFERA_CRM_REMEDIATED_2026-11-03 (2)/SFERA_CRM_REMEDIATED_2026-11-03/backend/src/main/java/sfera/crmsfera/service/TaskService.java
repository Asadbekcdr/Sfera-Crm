package sfera.crmsfera.service;

import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqGroupNotif;
import sfera.crmsfera.dto.request.ReqTask;
import sfera.crmsfera.dto.response.ResTask;
import sfera.crmsfera.entity.Group;
import sfera.crmsfera.entity.Task;
import sfera.crmsfera.entity.User;
import sfera.crmsfera.entity.enums.Role;
import sfera.crmsfera.exception.DataNotFoundException;
import sfera.crmsfera.exception.ForbiddenException;
import lombok.RequiredArgsConstructor;
import sfera.crmsfera.mapper.TaskMapper;
import org.springframework.stereotype.Service;
import sfera.crmsfera.repository.GroupRepository;
import sfera.crmsfera.repository.TaskRepository;
import sfera.crmsfera.repository.UserRepository;
import sfera.crmsfera.security.CustomUserDetails;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    private final GroupRepository groupRepository;
    private final TaskMapper taskMapper;
    private final NotificationService notificationService;

    @Transactional
    public ApiResponse<String> createTask(CustomUserDetails current, ReqTask reqTask) {
        User user = null;
        Group group = null;
        if (reqTask.getUserId() != null) {
            user = userRepository.findById(reqTask.getUserId()).orElseThrow(
                    () -> new DataNotFoundException("User topilmadi")
            );
        } else if (reqTask.getGroupId() != null) {
            group = groupRepository.findById(reqTask.getGroupId()).orElseThrow(
                    () -> new DataNotFoundException("Group topilmadi")
            );
        }
        assertCanAssign(current, user, group);

        Task task = Task.builder()
                .title(reqTask.getTitle())
                .description(reqTask.getDescription())
                .deadline(reqTask.getDeadline())
                .group(group)
                .user(user)
                .build();
        taskRepository.save(task);

        if (group != null) {
            notificationService.sendGroupNotification(ReqGroupNotif.builder()
                    .groupId(group.getId())
                    .title("Sfera Academy xabarnomasi")
                    .description("Sizga " + task.getTitle() + " nomli vazifa yuklandi! " +
                            "Siz " + task.getDeadline() + " sanagacha taskni tugatishingiz kerak")
                    .build());
        }
        return ApiResponse.success(null, "Task created");
    }

    @Transactional
    public ApiResponse<String> updateTask(CustomUserDetails current, Long taskId, ReqTask reqTask) {
        Task task = taskRepository.findById(taskId).orElseThrow(
                () -> new DataNotFoundException("Task topilmadi")
        );
        assertCanReadTask(current, task);

        User newUser = task.getUser();
        Group newGroup = task.getGroup();
        if (reqTask.getUserId() != null) {
            newUser = userRepository.findById(reqTask.getUserId()).orElseThrow(
                    () -> new DataNotFoundException("User topilmadi")
            );
        }
        if (reqTask.getGroupId() != null) {
            newGroup = groupRepository.findById(reqTask.getGroupId()).orElseThrow(
                    () -> new DataNotFoundException("Group topilmadi")
            );
        }
        assertCanAssign(current, newUser, newGroup);

        task.setUser(newUser);
        task.setGroup(newGroup);
        if (reqTask.getTitle() != null) task.setTitle(reqTask.getTitle());
        if (reqTask.getDescription() != null) task.setDescription(reqTask.getDescription());
        if (reqTask.getDeadline() != null) task.setDeadline(reqTask.getDeadline());
        taskRepository.save(task);
        return ApiResponse.success(null, "Task updated");
    }

    @Transactional
    public ApiResponse<String> deleteTask(CustomUserDetails current, Long taskId) {
        Task task = taskRepository.findById(taskId).orElseThrow(
                () -> new DataNotFoundException("Task topilmadi")
        );
        assertCanReadTask(current, task);
        if (!isAdministratorOrManager(current)) {
            throw new ForbiddenException("Faqat manager yoki admin taskni o‘chirishi mumkin");
        }
        taskRepository.delete(task);
        return ApiResponse.success(null, "Task deleted");
    }

    @Transactional(readOnly = true)
    public ApiResponse<ResTask> getTask(CustomUserDetails current, Long taskId) {
        Task task = taskRepository.findById(taskId).orElseThrow(
                () -> new DataNotFoundException("Task topilmadi")
        );
        assertCanReadTask(current, task);
        return ApiResponse.success(taskMapper.toDto(task), "Task found");
    }

    @Transactional(readOnly = true)
    public ApiResponse<List<ResTask>> getAllTasks(CustomUserDetails current) {
        List<ResTask> list = taskRepository.findAll().stream()
                .filter(task -> canReadTask(current, task))
                .map(taskMapper::toDto)
                .toList();
        return ApiResponse.success(list, "Tasks found");
    }

    private void assertCanReadTask(CustomUserDetails current, Task task) {
        if (!canReadTask(current, task)) {
            throw new ForbiddenException("Bu taskga kirish taqiqlangan");
        }
    }

    private boolean canReadTask(CustomUserDetails current, Task task) {
        if (isAdministratorOrManager(current)) return true;
        if (!isTeacher(current) || current.getUser() == null) return false;
        if (task.getGroup() != null && task.getGroup().getTeacher() != null
                && current.getUser().getId().equals(task.getGroup().getTeacher().getId())) return true;
        return task.getUser() != null && current.getUser().getId() != null
                && current.getUser().getId().equals(task.getUser().getId());
    }

    private void assertCanAssign(CustomUserDetails current, User user, Group group) {
        if (isAdministratorOrManager(current)) return;
        if (!isTeacher(current) || current.getUser() == null || current.getUser().getId() == null) {
            throw new ForbiddenException("Bu task amaliga ruxsat yo‘q");
        }
        Long currentUserId = current.getUser().getId();
        boolean ownGroup = group != null && group.getTeacher() != null
                && currentUserId.equals(group.getTeacher().getId());
        boolean selfAssigned = user != null && currentUserId.equals(user.getId());
        boolean groupAllowed = group == null || ownGroup;
        boolean userAllowed = user == null || selfAssigned;
        if ((!ownGroup && !selfAssigned) || !groupAllowed || !userAllowed) {
            throw new ForbiddenException("Teacher faqat o‘z guruhiga yoki o‘ziga task biriktirishi mumkin");
        }
    }

    private boolean isAdministratorOrManager(CustomUserDetails current) {
        String role = current.getRole();
        return Role.ROLE_ADMIN.name().equals(role)
                || Role.ROLE_SUPER_ADMIN.name().equals(role)
                || Role.ROLE_MANAGER.name().equals(role);
    }

    private boolean isTeacher(CustomUserDetails current) {
        return Role.ROLE_TEACHER.name().equals(current.getRole());
    }
}
