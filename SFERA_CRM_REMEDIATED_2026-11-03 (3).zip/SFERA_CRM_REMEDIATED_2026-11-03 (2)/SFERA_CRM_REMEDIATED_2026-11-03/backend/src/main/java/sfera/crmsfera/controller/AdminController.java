package sfera.crmsfera.controller;

import sfera.crmsfera.configuration.TrackAction;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.UserDTO;
import sfera.crmsfera.dto.request.AuthRegister;
import sfera.crmsfera.dto.response.ResPageable;
import sfera.crmsfera.dto.response.UserResponse;
import sfera.crmsfera.entity.enums.ActionType;
import sfera.crmsfera.entity.enums.Role;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import sfera.crmsfera.security.CustomUserDetails;
import sfera.crmsfera.service.AuthService;
import sfera.crmsfera.service.UserService;

import java.util.List;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
public class AdminController {
    private final AuthService authService;
    private final UserService userService;

    @TrackAction(
            type = ActionType.ADMIN_CREATED,
            description = "Admin yaratildi"
    )
    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN')")
    @PostMapping("/saveUser")
    public ResponseEntity<ApiResponse<String>> userLogin(
            @Valid @RequestBody AuthRegister register
    ){
        return ResponseEntity.ok(authService.saveUser(register, Role.ROLE_ADMIN));
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN')")
    @PostMapping("/save-role")
    public ResponseEntity<ApiResponse<String>> saveRoleUser(
            @Valid @RequestBody AuthRegister register,
            @RequestParam Role role) {
        if (role == Role.ROLE_SUPER_ADMIN) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Super Adminni oddiy user creation orqali yaratib bo‘lmaydi"));
        }
        return ResponseEntity.ok(authService.saveUser(register, role));
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<UserResponse>> getUserById(@PathVariable Long userId) {
        return ResponseEntity.ok(userService.getOneUser(userId));
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @PutMapping
    public ResponseEntity<ApiResponse<String>> updateUser(@AuthenticationPrincipal CustomUserDetails current,
                                                          @RequestBody UserDTO req){
        return ResponseEntity.ok(userService.update(current, req));
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @DeleteMapping("/{userId}")
    public ResponseEntity<ApiResponse<String>> delete(@PathVariable Long userId){
        return ResponseEntity.ok(userService.deleteById(userId));
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @GetMapping("/list")
    @Operation(summary = "Adminlarning LIST da malumoti")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllList(){
        return ResponseEntity.ok(userService.getAllList(Role.ROLE_ADMIN));
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_SUPER_ADMIN')")
    @GetMapping
    @Operation(summary = "Adminlarni FILTR qilish PAGE da")
    public ResponseEntity<ApiResponse<ResPageable>> getAll(@RequestParam(required = false) String name,
                                                           @RequestParam(required = false) String phone,
                                                           @RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "10") int size){
        return ResponseEntity.ok(userService.getAllUsersSearch(name, phone, Role.ROLE_ADMIN,page,size));
    }
}
