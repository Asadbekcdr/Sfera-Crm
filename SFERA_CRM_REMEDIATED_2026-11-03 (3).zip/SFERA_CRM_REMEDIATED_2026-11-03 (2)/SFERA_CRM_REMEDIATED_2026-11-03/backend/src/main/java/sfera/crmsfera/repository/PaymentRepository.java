package sfera.crmsfera.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import sfera.crmsfera.entity.Payment;
import sfera.crmsfera.entity.enums.PaymentStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByIdempotencyKey(String idempotencyKey);
    @Query("select p from Payment p join p.student s where (:status is null or p.status = :status) and (:from is null or p.createdAt >= :from) and (:to is null or p.createdAt < :to) and (:q is null or :q = '' or lower(s.fullName) like lower(concat('%', :q, '%')) or s.phone like concat('%', :q, '%')) order by p.createdAt desc")
    Page<Payment> search(@Param("status") PaymentStatus status,
                         @Param("from") Instant from,
                         @Param("to") Instant to,
                         @Param("q") String q,
                         Pageable pageable);
    List<Payment> findAllByStudent_IdOrderByCreatedAtDesc(Long studentId);

    @Query("select coalesce(sum(p.amount), 0) from Payment p where p.status = :status and p.paidAt >= :from and p.paidAt < :to")
    BigDecimal sumAmount(@Param("status") PaymentStatus status, @Param("from") Instant from, @Param("to") Instant to);

    long countByStatus(PaymentStatus status);
    long countByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThan(PaymentStatus status, Instant from, Instant to);
    long countByStatusAndPaidAtGreaterThanEqualAndPaidAtLessThan(PaymentStatus status, Instant from, Instant to);
    long countByCreatedAtGreaterThanEqualAndCreatedAtLessThan(Instant from, Instant to);
}
