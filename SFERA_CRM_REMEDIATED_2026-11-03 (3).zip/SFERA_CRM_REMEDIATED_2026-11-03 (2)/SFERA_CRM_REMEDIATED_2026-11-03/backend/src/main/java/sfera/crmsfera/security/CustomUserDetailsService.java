package sfera.crmsfera.security;

import sfera.crmsfera.entity.Student;
import sfera.crmsfera.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import sfera.crmsfera.repository.StudentRepository;
import sfera.crmsfera.repository.UserRepository;

@Service
@RequiredArgsConstructor
public class   CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;

    @Override
    public UserDetails loadUserByUsername(String phone) throws UsernameNotFoundException {
        // Avval User ni tekshiramiz
        User user = userRepository.findByPhoneAndActiveTrue(phone).orElse(null);
        if (user != null) {
            return CustomUserDetails.fromUser(user);
        }

        // Agar User topilmasa → Student ni tekshiramiz
        Student student = studentRepository.findByPhoneAndActiveTrue(phone).orElse(null);
        if (student != null) {
            return CustomUserDetails.fromStudent(student);
        }

        // Ikkalasida ham topilmasa → exception
        throw new UsernameNotFoundException("User yoki Student topilmadi: " + phone);
    }
}
