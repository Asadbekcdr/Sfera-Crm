package sfera.crmsfera.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class UserDTO {
    private Long id;
    private String fullName;
    private String phone;
    private String imageUrl;
    @Schema(hidden = true)
    private String role;
}
