package sfera.crmsfera.controller;


import sfera.crmsfera.configuration.TrackAction;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqCategory;
import sfera.crmsfera.dto.request.ReqCategoryDTO;
import sfera.crmsfera.dto.response.ResCategory;
import sfera.crmsfera.dto.response.ResPageable;
import sfera.crmsfera.entity.enums.ActionType;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import sfera.crmsfera.service.CategoryService;

import java.util.List;

@RestController
@RequestMapping("/category")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryService categoryService;

    @TrackAction(
            type = ActionType.CATEGORY_CREATED,
            description = "Category yaratildi"
    )
    @PostMapping
    @PreAuthorize("hasAnyRole('ROLE_MANAGER','ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<String>> saveCategory(@RequestBody ReqCategory reqCategory){
        return ResponseEntity.ok(categoryService.saveCategory(reqCategory));
    }

    @PutMapping("/update")
    @PreAuthorize("hasAnyRole('ROLE_MANAGER','ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<String>> updateCategory(@RequestBody ReqCategoryDTO reqCategoryDTO){
        return ResponseEntity.ok(categoryService.updateCategory(reqCategoryDTO));
    }

    @DeleteMapping("/{categoryId}")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<String>> deleteCategory(@PathVariable Long categoryId){
        return ResponseEntity.ok(categoryService.deleteCategory(categoryId));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<ResCategory>>> getCategories(){
        return ResponseEntity.ok(categoryService.getAllCategory());
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<ResPageable>> searchCategory(@RequestParam(required = false) String name,
                                                                   @RequestParam(defaultValue = "0") int page,
                                                                   @RequestParam(defaultValue = "10") int size){
        return ResponseEntity.ok(categoryService.searchCategory(name, page, size));
    }

    @GetMapping("/{categoryId}")
    public ResponseEntity<ApiResponse<ResCategory>> getCategory(@PathVariable Long categoryId){
        return ResponseEntity.ok(categoryService.getCategoryById(categoryId));
    }

//    @PostMapping("/start-test/{categoryId}")
//    public ResponseEntity<ApiResponse<List<ResponseQuestion>>> startTest(@AuthenticationPrincipal CustomUserDetails student,
//                                                                         @PathVariable Long categoryId) {
//        return ResponseEntity.ok(categoryService.startTest(student,categoryId));
//    }

}
