-- Payment state/audit migration.
-- Existing legacy PENDING values are migrated before the application enum is read.

CREATE TABLE IF NOT EXISTS payments (
    id BIGSERIAL PRIMARY KEY,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ,
    created_by VARCHAR(255),
    updated_by VARCHAR(255),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    student_id BIGINT NOT NULL REFERENCES student(id),
    amount NUMERIC(19,2) NOT NULL,
    payment_method VARCHAR(32) NOT NULL,
    idempotency_key VARCHAR(120),
    reference_number VARCHAR(120),
    status VARCHAR(20) NOT NULL,
    paid_at TIMESTAMPTZ,
    rejection_reason VARCHAR(500),
    submitted_by VARCHAR(32),
    approved_by VARCHAR(32),
    approved_at TIMESTAMPTZ,
    version BIGINT NOT NULL DEFAULT 0
);

ALTER TABLE payments ADD COLUMN IF NOT EXISTS submitted_by VARCHAR(32);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS approved_by VARCHAR(32);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS version BIGINT NOT NULL DEFAULT 0;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(120);

UPDATE payments SET status = 'PENDING_APPROVAL' WHERE status = 'PENDING';
UPDATE payments SET submitted_by = COALESCE(submitted_by, created_by, 'SYSTEM_MIGRATION');
UPDATE payments SET idempotency_key = COALESCE(idempotency_key, 'legacy-' || id::text);

ALTER TABLE payments ALTER COLUMN submitted_by SET NOT NULL;
ALTER TABLE payments ALTER COLUMN idempotency_key SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uk_payments_idempotency_key ON payments(idempotency_key);
CREATE INDEX IF NOT EXISTS idx_payment_student ON payments(student_id);
CREATE INDEX IF NOT EXISTS idx_payment_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payment_paid_at ON payments(paid_at);
