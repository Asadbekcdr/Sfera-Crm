-- Canonical audit trail table used by ActionAuditAspect and ActionEventService.
-- Safe for fresh installs and existing databases; no destructive operations.
CREATE TABLE IF NOT EXISTS action_event (
    id BIGSERIAL PRIMARY KEY,
    action_type VARCHAR(64) NOT NULL,
    description VARCHAR(500),
    user_id BIGINT,
    user_role VARCHAR(64),
    entity_name VARCHAR(160),
    entity_id BIGINT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_action_event_created_at ON action_event(created_at);
CREATE INDEX IF NOT EXISTS idx_action_event_user_id ON action_event(user_id);
CREATE INDEX IF NOT EXISTS idx_action_event_entity ON action_event(entity_name, entity_id);
