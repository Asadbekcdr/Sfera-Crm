# Database migrations and upgrade policy

The canonical backend uses Flyway as the schema source of truth. Runtime schema generation is set to `spring.jpa.hibernate.ddl-auto=validate`; Hibernate must validate the schema after Flyway, not mutate it.

## Migration sequence

| Version | File | Purpose |
|---|---|---|
| V1 | `backend/src/main/resources/db/migration/V1__initial_schema.sql` | Establish the initial canonical schema for a clean database. |
| V2 | `backend/src/main/resources/db/migration/V2__payment_state_and_audit.sql` | Normalize legacy `PENDING` payment state, backfill submitter/idempotency data, add approval audit/version fields and indexes. |
| V3 | `backend/src/main/resources/db/migration/V3__action_event_audit.sql` | Create the `action_event` audit table and query indexes when absent. |

`baseline-on-migrate=true` with `baseline-version=1` supports a pre-existing non-empty schema that has no Flyway history: Flyway records version 1 as the baseline and runs later migrations. Verify the production snapshot's actual tables/columns before using that upgrade path; a baseline is not a schema reconciliation tool.

## Local verification

Fresh-database verification (PostgreSQL required):

```bash
createdb sfera_fresh_test
cd backend
JWT_SECRET='test-only-secret-at-least-32-bytes' \
SPRING_DATASOURCE_URL='jdbc:postgresql://127.0.0.1:5432/sfera_fresh_test' \
SPRING_DATASOURCE_USERNAME='postgres' \
SPRING_DATASOURCE_PASSWORD='local-password' \
./mvnw test
```

For an upgrade test, import a reviewed schema-only snapshot of a legacy database into a separate disposable database, omit its `flyway_schema_history` table, then run the same application-context test against that database. Do not use live production data for a development test.

## Production safeguards

- Take and verify a recoverable backup before applying migrations.
- Review the migration plan and affected row counts against a sanitized production-shaped snapshot.
- Apply only the canonical migrations; do not replace this backend with the standalone reference ZIP.
- Do not enable Hibernate `update`/`create` in production.
- Retain migration logs and verify Flyway history and Hibernate validation after deployment.

The included test evidence documents the supplied sandbox's PostgreSQL run only. It does not substitute for a staged migration against the actual production schema.
