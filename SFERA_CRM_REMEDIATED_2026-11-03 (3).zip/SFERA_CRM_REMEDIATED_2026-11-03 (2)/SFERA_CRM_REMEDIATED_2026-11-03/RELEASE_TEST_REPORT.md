# SFERA CRM — release verification report

**Run date:** 2026-10-30. **Environment:** Ubuntu 24.04; Node `v22.23.4`; pnpm `11.25.0`; OpenJDK `21.0.12.1` (Maven compiler target Java 17); PostgreSQL `16.15`. **Overall product gate: BLOCKED — not production ready.** The checks below cover this source snapshot, not all acceptance requirements or a production deployment.

## Final frontend results

| Command | Result | Evidence |
|---|---|---|
| `pnpm install --frozen-lockfile` | PASS — lockfile install completed (“Already up to date”). | `release-evidence/frontend-install.log` |
| `pnpm exec tsc -b --pretty false` | PASS — exit code 0, no TypeScript diagnostics. | `release-evidence/frontend-typecheck-final.log` |
| `pnpm lint` | PASS — exit code 0; 0 errors and **29 warnings**, mainly React Fast Refresh export warnings. | `release-evidence/frontend-lint-final.log` |
| `pnpm test` | PASS — **32 browser test files, 158 tests**, 0 failures, 0 skipped. | `release-evidence/frontend-full-test-final-158.log` |
| `pnpm build` | PASS — Vite production build completed. | `release-evidence/frontend-build-final.log` |
| Focused API alias test | PASS — bulk-attendance alias rewrites to `/attendance/bulk` (1 test). | Included in the full browser log; separately rerunnable with `pnpm exec vitest run --browser.headless --maxWorkers=1 --fileParallelism=false src/lib/api-client.test.ts`. |

The original bundle’s frontend baseline was **79/156 passing and 77 failing**; the raw baseline is retained as `release-evidence/intermediate-frontend-baseline-79-of-156.txt`. The complete final suite ran without skipping/deleting tests; some test expectations were updated to the active locale, actual accessible labels/route contract and safe disabled-submit behavior, and regression coverage was added. The full test suite is Chromium Vitest browser testing, not a comprehensive multi-role Playwright E2E matrix.

## Final backend and PostgreSQL results

| Command/scenario | Result | Evidence |
|---|---|---|
| Full Maven test suite on a newly created empty PostgreSQL database | PASS — **29 tests**, 0 failures/errors/skips; Flyway applied V1–V3 and Hibernate `validate` completed. | `release-evidence/backend-fresh-postgres-final-29.log` |
| Full Maven test suite on a schema-only legacy database without Flyway history | PASS — **29 tests**, 0 failures/errors/skips; Flyway baselined the non-empty schema at v1, applied V2–V3 through v3, and Hibernate `validate` completed. | `release-evidence/backend-legacy-postgres-final-29.log`, `release-evidence/legacy-schema-import-final.log` |
| Focused task/mark regressions | PASS — 13 tests, 0 failures/errors/skips, including cross-group reassignment denials. | `release-evidence/backend-cross-group-focused-13-pass.log` |

Run from `backend/` with a disposable local database and a test-only JWT secret (no production credential used):

```bash
SPRING_DATASOURCE_URL='jdbc:postgresql://127.0.0.1:5432/<test-db>' \
SPRING_DATASOURCE_USERNAME='<local-test-user>' \
SPRING_DATASOURCE_PASSWORD='<local-test-password>' \
JWT_SECRET='<test-only-random-secret-at-least-32-bytes>' \
./mvnw test -Dstyle.color=never
```

The legacy fixture is a schema-only Hibernate-generated dump, not production data. Flyway emitted non-fatal “relation/column already exists, skipping” warnings for idempotent V2/V3 DDL overlapping objects in these generated schemas; migration execution and Hibernate validation still succeeded. Maven also emitted non-fatal Lombok builder/deprecation and PostgreSQL dialect warnings, plus Mockito’s dynamic-agent warning. One Maven dependency-metadata request to the optional Flyway GitHub package returned HTTP 401; Maven resolved dependencies and completed the tests successfully. None of these warnings is represented as a clean warning-free build.

## Intermediate failures and their resolution

These attempts are disclosed; their outputs are preserved where practical in `release-evidence/`.

- The supplied frontend baseline had 77 failing tests out of 156. Investigation found both stale locale/navigation assertions and genuine accessibility/behavior defects. The full final browser run is 158/158 passing.
- During supplemental frontend wiring, the first TypeScript check reported a set of `string | number` group-ID type mismatches and one unused import. Numeric backend IDs were normalized at the UI boundary and the import was removed; final typecheck exited 0. The captured diagnostics are in `intermediate-frontend-typecheck-group-id-errors.txt`.
- The first supplemental backend compile found that inherited `Group.id` cannot be set through Lombok’s builder; fixtures were corrected to set inherited IDs through the entity API. The next focused run exposed test assumptions about the project’s custom `ForbiddenException` and a partial-update fixture that did not model the required current association. The service behavior/fixtures/assertions were corrected and the final focused suite passed. Raw captures are `intermediate-backend-group-builder-compile-failure.txt` and `intermediate-backend-ownership-fixture-failure.txt`.
- An early Spring application-context test run lacked the required `JWT_SECRET`; the final fresh and legacy runs supplied an explicitly test-only value and both passed. An earlier compile caught the nonexistent `ROLE_STUDENT` enum constant and a Mockito generic mock mismatch; both were corrected before the final 29-test runs. Sanitized diagnostics are retained in `intermediate-backend-role-enum-and-mockito-type-errors.txt` and `intermediate-missing-test-jwt-context-failure.txt`.

## Not tested or still blocked

The tests do not certify password recovery, refresh/revocation/logout, login rate limiting, HttpOnly token storage, all-role/tenant isolation, complete API contract, complete finance/student/assignment/grade workflows, file storage security, Telegram/SSE production behavior, production CORS values, production-shaped data migration, deployment, load/performance, backup/restore or every viewport/accessibility requirement. The artifact is a corrected continuation snapshot; see `RELEASE_AUDIT.md` and `SUPPLEMENTAL_AUDIT_REVIEW.md` for the full blocker register.
