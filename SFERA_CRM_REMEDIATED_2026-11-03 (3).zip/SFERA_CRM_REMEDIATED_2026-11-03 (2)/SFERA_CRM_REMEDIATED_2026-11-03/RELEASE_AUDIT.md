# SFERA CRM — release audit and blocker register

**Audit date:** 2026-10-30. **Sources:** uploaded handoff/audit files in `TASKS/`; primary code is `CODE/frontend-full-remediated.zip` extracted as the project root, with its bundled `backend/` canonical. The standalone backend ZIP remains reference-only and was not merged wholesale. **Release decision: BLOCKED — not production ready.**

## Verified remediation in this continuation

| Finding | Code change | Evidence |
|---|---|---|
| Task partial updates could clear omitted user/group links. | `backend/.../service/TaskService.java` retains existing associations; teacher task reads/mutations/assignments are principal-scoped; every non-null group/user assignment must independently be within the teacher's own scope. Cross-group reassignment is rejected. | Full Maven tests: 29 passed on both fresh and schema-only legacy PostgreSQL DBs; task regressions include partial update and foreign-group reassignment. |
| Disabled accounts could continue using a valid JWT; inactive students could be found by phone. | `JwtAuthFilter.java` and `CustomUserDetailsService.java` reject disabled principals and filter inactive students. | `JwtAuthFilterTest`; included in both 29-test full backend runs. |
| Attendance/mark single-record access and teacher mark writes were insufficiently scoped. | `AttendanceService`, `AttendanceController`, `MarkService`, and `MarkController` receive principal context. Attendance/mark detail reads enforce supported owner scope. Teachers may only mutate their own group's marks; a mark cannot be reassigned to another teacher's student. | `AttendanceOwnershipTest`, `MarkOwnershipTest` and `AttendanceControllerBulkTest`; included in 29-test PostgreSQL runs. |
| Global attendance SSE fan-out could cross group boundaries. | `AttendanceService` stores emitters per group and broadcasts only within the matching group. | `AttendanceSseIsolationTest`; included in the 29-test suites. This is unit coverage, not a deployed multi-client SSE test. |
| Credentialed CORS accepted origin patterns that could include wildcards. | `SecurityConfig` now requires explicit HTTP(S) origins and fails startup for wildcard, empty, malformed, path/query/user-info values. | `SecurityConfigCorsTest` (valid explicit origins and negative cases); included in 29-test runs. Production allowlist/preflight still needs deployment verification. |
| Frontend attendance payload did not match the backend's legacy attendance contract. | `api-client.ts` rewrites `/api/v1/attendance/bulk` to `/attendance/bulk`; `AttendanceController` adapts group/date/records to the canonical secured attendance service. Teacher page now loads principal-scoped real groups/rosters, maps UI states to backend enum values, and does not display a demo roster in API mode. | Frontend route-alias test (part of 158 browser tests), `AttendanceControllerBulkTest`, and the full backend suite. |
| API mode mixed real data with hard-coded teacher/finance demo data or local-only “saved” messages. | Teacher dashboard uses backend metrics only; empty/error group states do not fall back to sample groups. Attendance uses backend groups. Assignment/grade screens and finance students screen explicitly state that persistence is not wired and hide demo data. Unconfigured SMS no longer claims delivery. | Frontend suite (158 passed); no full role E2E or live browser/API environment was run. |
| Payment idempotency keys could be reused with a different request; invoice/debt metrics were fabricated without an invoice ledger. | `FinanceService` rejects mismatched key reuse and uses payment-backed aggregates; unsupported invoice/debt fields stay `null`, rendered as unavailable. | Finance backend regressions and frontend tests included in suite. A complete billing ledger remains absent. |
| Fresh installs and legacy schemas needed a verified migration chain. | Flyway V1 initial schema plus V2 payment and V3 action-event migrations; Hibernate validates schema. | Each final fresh and legacy PostgreSQL suite: 29 passed, 0 failed/errors/skipped; legacy run baselined history-less schema and migrated to v3. |
| Auth/forms/settings/tasks had real accessibility and behavior regressions; unsupported student/invitation actions claimed success. | Sign-in actual input labels/password error, locale-aware forms, theme reset, task mutation/import tests, and explicit no-save/no-invitation behavior updated. | Full Chromium browser suite: 32 files, 158 tests passed, 0 failed/skipped. |

For the independent audit’s finding-by-finding disposition (ARCH/SEC/DB/BE/FE/API/DEAD/PERF/A11Y/RESP/TEST IDs), see [`SUPPLEMENTAL_AUDIT_REVIEW.md`](SUPPLEMENTAL_AUDIT_REVIEW.md) and the original [`TASKS/SFERA_CRM_FULL_AUDIT.md`](TASKS/SFERA_CRM_FULL_AUDIT.md).

## Open release blockers

### P0 — identity, authorization and tenant isolation

- The frontend still stores a browser-readable bearer token; an HttpOnly/Secure session or BFF strategy and server-side logout/session revocation are not implemented.
- Clerk routes/dependency and the custom JWT flow coexist; a single supported auth system has not been chosen. Password reset/OTP, refresh rotation, logout revocation, device/session management and login/recovery rate limiting are missing or unverified.
- `PARENT` versus frontend `Student` mapping and the complete backend/frontend permission matrix remain inconsistent/unproven. Academy/tenant isolation and all role/resource boundaries have not been tested across every controller. The added task/mark/attendance checks are targeted fixes, not a global authorization certification.
- Production CORS origins, secret-manager/rotation, deployment profile and real preflight behavior have not been tested. The wildcard guard does not establish the production allowlist.

### P1 — business functionality and data integrity

- There is no canonical invoice/debt/refund/receipt/reconciliation ledger. Payment-only aggregates are made honest, but allocations, partial payment, overpayment, reversals, overdue accounting and receipts are incomplete.
- Student create/edit needs parent/group fields and a compatible complete API; invitation/recovery APIs are absent. The safe UI state means no save occurred; it does not make that workflow complete.
- Leads/conversion/enrollment, assignments/submissions, grade publishing/history, attendance correction, group/course lifecycle, schedule/material exports and student/parent end-to-end workflows remain incomplete or unverified. Assignment and grade UI now avoids claiming backend persistence, but remains unavailable in API mode.
- Every frontend call has not been checked against an OpenAPI-generated method/path/DTO/enums/validation/pagination/error/role contract. Login user construction still depends on manual JWT claim mapping.
- Schema constraint/index/concurrency review, phone normalization, query profiling, upload/download authorization and Telegram delivery/retry behavior are incomplete.

### P2/P3 — release operations and product quality

- Full responsive/accessibility checks across roles/viewports, Lighthouse, load/performance, production-shaped migration rehearsal, observability and backup/restore drills were not run.
- Lint passes with **29 warnings** (mostly React Fast Refresh export warnings); backend build emits Lombok/deprecation and dynamic Mockito-agent warnings. They are retained, not suppressed.
- The delivered package excludes installed dependencies/build outputs and local secrets, but preserves test/audit logs for traceability.

## Release gate

Passing the included test suites does not satisfy the handoff’s full acceptance matrix. Treat this artifact as a corrected, tested continuation snapshot only; do not deploy until all applicable P0/P1 blockers above pass production-shaped integration and role/tenant acceptance.
