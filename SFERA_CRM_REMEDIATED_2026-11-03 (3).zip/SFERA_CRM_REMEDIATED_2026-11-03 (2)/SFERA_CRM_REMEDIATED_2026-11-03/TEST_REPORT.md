# Yakuniy test natijalari — 2026-10-30

## Frontend

- `pnpm install --frozen-lockfile` — PASS.
- `pnpm exec tsc -b --pretty false` — PASS, yakuniy exit code 0 va diagnostics yo‘q.
- `pnpm lint` — PASS, 0 error, 29 warning (asosan React Fast Refresh export qoidalari).
- `pnpm test` — PASS, 32 browser test fayli, 158 test; 0 failed, 0 skipped.
- `pnpm build` — PASS, Vite production build yakunlandi.

## Backend/PostgreSQL

- Fresh PostgreSQL bazasida to‘liq `./mvnw test -Dstyle.color=never` — PASS: 29 test, 0 failure/error/skip; Flyway V1–V3, Hibernate `validate` o‘tdi.
- Schema-only legacy fixture va Flyway history’siz bazada to‘liq suite — PASS: 29 test, 0 failure/error/skip; V1 baseline qo‘yildi, V2–V3 qo‘llandi, Hibernate `validate` o‘tdi.
- Task/mark cross-group authorization focused run — PASS: 13 test, 0 failure/error/skip.

Test-only `JWT_SECRET` va disposable local PostgreSQL test account ishlatildi; production credential arxivga kiritilmagan. Migratsiyalarda mavjud jadvallar/ustunlar uchun idempotent “already exists, skipping” warninglari, Java/Lombok/Mockito ogohlantirishlari bor; ular build yoki testni yiqitmadi.

Birlamchi baseline’da frontend 156 testdan 79 tasi o‘tib, 77 tasi yiqilgan. Oraliq typecheck/backend test xatolari ham tuzatilib, hisobot va `release-evidence/` ichida qayd etildi. Hozirgi PASS natijalar ular yashirilganini emas, to‘liq qayta ishga tushirilganini bildiradi.

Aniq buyruqlar, raw loglar, failure captures va bloklovchilar `RELEASE_TEST_REPORT.md`, `RELEASE_AUDIT.md`, `SUPPLEMENTAL_AUDIT_REVIEW.md` va `release-evidence/` ichida. To‘liq role/tenant E2E, production DB, deploy, load, backup/restore va barcha biznes oqimlari tekshirilmadi. Release holati: **BLOCKED — production ready emas.**
