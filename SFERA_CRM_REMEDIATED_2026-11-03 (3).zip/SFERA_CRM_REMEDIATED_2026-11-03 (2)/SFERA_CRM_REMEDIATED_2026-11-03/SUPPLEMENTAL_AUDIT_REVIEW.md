# Qo‘shimcha kod auditi — topilmalarning holati

**Manba:** `TASKS/SFERA_CRM_FULL_AUDIT.md` (2026-10-30 mustaqil audit). Bu hujjat source-code auditni qayta ko‘rib, qaysi topilma amalda tuzatilgani va qaysi biri hali yopilmaganini ajratadi. **Umumiy qaror: BLOCKED — productionga chiqarish mumkin emas.**

| Audit ID / mavzu | Holat | Amalga oshirilgan ish / ochiq sabab |
|---|---|---|
| ARCH-001, ARCH-003 / canonical backend va API aliaslari | Qisman | Canonical manba bundled `backend/` Spring Boot bo‘lib qoladi; standalone reference merge qilinmadi. Attendance bulk uchun alias va controller adapter qo‘shilib, alias unit test qilindi. Hamma frontend chaqiruvi uchun OpenAPI contract hali yo‘q. |
| ARCH-002, DEAD-001 / Clerk va JWT parallel auth | Ochiq | Clerk route/dependency va backend JWT birga qolgan; auth arxitekturasi tanlanib yakunlanmadi. |
| SEC-001 / JWT claims | Qisman | Disabled principal endi JWT filterdan o‘tmaydi, inactive student phone lookup’dan chiqariladi. Wrong issuer/audience/expiry/type uchun to‘liq HTTP integration matritsasi, refresh/revoke/logout yo‘q. |
| SEC-002 / browser-readable token | Ochiq | Auth-store tokenni JS o‘qiy oladigan cookie/state orqali saqlaydi. HttpOnly backend cookie yoki BFF/session modeli joriy qilinmadi. |
| SEC-003 / credentialed CORS wildcard | Qisman yopildi | `SecurityConfig` explicit HTTP(S) origin talab qiladi va wildcard/path/malformed/empty qiymatda startupni to‘xtatadi; unit test bor. Deploy muhitidagi real allowlist, preflight va production secret/config tekshiruvi bajarilmadi. |
| SEC-004 / demo account profile | Kuzatuv | `DataLoader` dev profilga bog‘langan; production profilda haqiqiy deployment test qilinmadi. |
| SEC-005 / Parent va Student roli | Ochiq | Backend role enum va frontend token mapping o‘rtasidagi `PARENT`/`Student` farqi hamda barcha ruxsat matritsasi sinxronlashtirilmagan. |
| SEC-006 / ownership, tenant isolation | Qisman | Task o‘qish/yozish/assignment, mark o‘qish/yozish/reassignment va attendance detail ownership tekshirildi; SSE emitterlar group bo‘yicha ajratildi; targeted negative regressiyalar bor. Barcha controllerlarda academy/tenant va barcha rollar bo‘yicha isbot yo‘q. |
| SEC-007 / brute-force, recovery, sessions | Ochiq | Login rate limiting, parolni tiklash server lifecycle’i, refresh rotation, logout revocation va session/device boshqaruvi yo‘q yoki to‘liq sinovdan o‘tmagan. |
| SEC-008 / file security | Ochiq | Real storage bilan upload/download authorization, signature/MIME scan, malware va retention tekshiruvi bajarilmadi. |
| DB-001 / migrations | Tasdiqlangan qism | Flyway V1–V3 clean DB va history’siz schema-only legacy fixture’da bajarilib, Hibernate `validate` o‘tdi; bu production snapshot compatibility kafolati emas. |
| DB-002 / constraints & performance | Ochiq | FK/unique/check/index, concurrency, timezone/phone/money va N+1 review to‘liq emas. |
| DB-003, BE-001, API-003 / invoices and debt ledger | Ochiq | Summary invoice/debt metrikalarini uydirmaydi (mavjud bo‘lmagan ledger uchun `null`); payment idempotency key payload mosligi tekshiriladi. Invoice, allocation, partial payment, refund, receipt/reconciliation to‘liq emas. |
| BE-002 / task partial update | Tuzatildi | Omitted user/group relation saqlanadi; boshqa teacher groupiga ko‘chirish ham rad etiladi va test bilan qoplanadi. |
| BE-003 / student create | Ochiq, yolg‘on muvaffaqiyat bartaraf | Backend contract talab qiladigan parent/group ma’lumoti UI’da yo‘q. API rejimida demo student ekranlari yashirilib, saqlanmadi deb aniq ko‘rsatiladi. |
| BE-004 / leads, enrollment, grades, assignments, attendance | Qisman | Attendance UI’ning bulk contracti backend bilan moslashtirildi; assignment va grade sahifalari API rejimida soxta muvaffaqiyatni to‘xtatadi. Boshqa lifecycle va role E2E oqimlari hali yo‘q. |
| BE-005 / Telegram | Ochiq | Runtime, retry, duplicate prevention va monitoring bu sessiyada sinovdan o‘tmadi. |
| FE-001, DEAD-002 / demo fallback | Qisman | Teacher dashboard API rejimida faqat backend metrikalarini ko‘rsatadi; attendance backend guruhlarini talab qiladi; assignments, grades va finance student demo yozuvlari API rejimida yashiriladi. Qolgan barcha modullarda mock/localStorage oqimi audit qilinmadi. |
| FE-002 / incomplete API wiring | Ochiq | Selected sahifalarda live mode’ni xavfsiz chekladik; leads, reports va boshqa modullarni real API bilan ulash yakunlanmadi. |
| FE-003 / RBAC | Ochiq | Frontend va backend permission matrix hamma rol/endpoint bo‘yicha contract-test qilinmadi. |
| FE-004, TEST-001 / browser tests | Joriy run PASS | Chromium Vitest full suite: 32 fayl, 158 test, 0 failure/skip. Bu oldingi 79/156 baseline xatolarini va yangi qo‘shimchalarni qamraydi; to‘liq Playwright E2E emas. |
| FE-005, A11Y-001, RESP-001, PERF-001/002 | Ochiq | Barcha viewport/rol bo‘yicha a11y, responsive, Lighthouse, load/performance va query profiling bajarilmadi. |
| API-001, API-002 | Qisman | Attendance bulk route alias/DTO contract unit regressiyasi bor; login user modeli JWT claimlardan qo‘lda tuziladi. Barcha route, DTO, validation/error, pagination va auth role contract testlari yo‘q. |
| TEST-002 | Qisman | Task/mark/attendance/JWT/CORS uchun targeted testlar mavjud; to‘liq role×resource×tenant 403 matrix hali talab qilinadi. |
| DEAD-003 | Qisman | Release ZIP dependency/build/temp screenshot/env secretsiz tuziladi; audit va test loglar traceability uchun qoldiriladi. |

## Productiondan oldingi bloklar

1. HttpOnly/Secure session strategiyasi, recovery/refresh/revoke, login rate-limit va Clerk/custom JWT yagona auth yo‘li.
2. Barcha endpointlarda tenant isolation va rol chegaralari uchun server-side negative/integration testlar.
3. To‘liq invoice/debt/refund/receipt ledger va payment concurrency/idempotency integrity.
4. Student lifecycle/invitation, assignment/grade, leads/enrollment va boshqa API-backed business workflowlar.
5. File, Telegram, production CORS/secrets, observability, backup/restore, deployment, performance va viewport/a11y acceptance.

Testlar o‘tishi ushbu qolgan talablarni yopmaydi; release status **BLOCKED** bo‘lib qoladi.
