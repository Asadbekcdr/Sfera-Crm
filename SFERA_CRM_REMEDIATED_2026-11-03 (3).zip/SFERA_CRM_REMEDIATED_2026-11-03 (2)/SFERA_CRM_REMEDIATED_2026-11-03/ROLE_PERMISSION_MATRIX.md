# Sfera CRM — Role Permission Matrix

| Permission | Super Admin | Director | Manager | Finance | Teacher | Student |
|---|---:|---:|---:|---:|---:|---:|
| Dashboard read | Yes | Yes | Yes | Yes | Own dashboard | Own dashboard |
| Users/roles manage | Yes | No | No | No | No | No |
| Students read | Yes | Reports only | Yes | Read for finance | Own groups only | Own record only |
| Students create/update/delete | Yes | No | Create/update | No | No | No |
| Groups manage | Yes | No | Operational | No | Own groups only | No |
| Courses manage | Yes | Read/report | Yes | No | Read | Read |
| Leads manage | Yes | Read/report | Yes | No | No | No |
| Payments create/approve/reject | Yes | No by default | No by default | Yes | No | No |
| Finance reports read | Yes | Yes | No by default | Yes | No | Own payments only |
| Attendance manage | Yes | Report | No by default | No | Own groups | Read own |
| Tasks | Full | Read/report | Manage | Read | Own tasks | Own tasks |
| Settings | Full | Own profile | Own profile | Own profile | Own profile | Own profile |

## Backend role model

Spring `Role` now contains `ROLE_SUPER_ADMIN`, `ROLE_DIRECTOR`, `ROLE_MANAGER`, `ROLE_FINANCE`, `ROLE_TEACHER` and the legacy `ROLE_PARENT`. Students remain a separate entity with `ROLE_STUDENT` in `CustomUserDetails`; this is documented because student credentials are stored separately from `users`.

Frontend `Unknown` is deny-by-default and has no permissions. Frontend permission checks do not replace backend checks.

## Known implementation boundary

The existing backend controllers fully cover the legacy academy modules. Finance payment persistence, idempotent payment creation and approval/rejection were added under `/api/v1/finance`. Leads and Courses still require their own persistent entities and migrations; the frontend must not present localStorage records as production data when backend mode is enabled.
